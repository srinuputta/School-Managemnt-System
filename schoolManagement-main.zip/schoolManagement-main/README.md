# schoolManagement
A basic simple JAVA code for school Management system (java beginners)


## create basic "School Manager System" with java OOP classes.

Classes : 
	-Students
	-Teachers
	-Funds

// Mony management System for school

keep track of students total fees,
fees already paid
teachers salary

//School
Teachers,
Students,
Total money earned,
Total money spent - teachers salary

//teacher
id
name
salary

//student
id
name
grade
fees paid
fees total
